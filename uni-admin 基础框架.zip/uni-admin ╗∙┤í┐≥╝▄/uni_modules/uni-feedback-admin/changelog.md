## 1.0.2（2022-06-23）
新增，应用[pages_init](https://uniapp.dcloud.io/plugin/publish.html#pages-init)当导入插件到项目工程时，自动合并本插件的页面路由到项目的pages.json
## 1.0.1（2021-05-12）
补充安装指南，新增uni-feedback-admin-menu.json
## 1.0.0（2021-05-11）
第一版
