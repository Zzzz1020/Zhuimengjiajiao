module.exports = {
  registerUser: require('./register-user'),
  registerAdmin: require('./register-admin'),
  registerUserByEmail: require('./register-user-by-email')
}
