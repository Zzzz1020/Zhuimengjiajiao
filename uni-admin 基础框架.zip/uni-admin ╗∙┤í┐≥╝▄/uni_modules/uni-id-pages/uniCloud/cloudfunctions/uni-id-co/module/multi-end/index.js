module.exports = {
  authorizeAppLogin: require('./authorize-app-login'),
  removeAuthorizedApp: require('./remove-authorized-app'),
  setAuthorizedApp: require('./set-authorized-app')
}
