/**
 * Google登录
 * @param {Object} params
 * @returns
 */
module.exports = async function (params = {}) {
  // 此接口暂未实现，欢迎向我们提交pr
  throw new Error('api[loginByGoogle] is not yet implemented')
}
