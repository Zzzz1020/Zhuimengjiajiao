<template>
  <view class="uni-container">
    <uni-forms ref="form" :model="formData" validateTrigger="bind">
      <uni-forms-item name="title" label="课程" required>
        <uni-easyinput placeholder="请输入课程名称" v-model="formData.title"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="navid" label="分类">
        <uni-data-picker v-model="formData.navid" collection="zmjj_course" field="_id as value, course as text"></uni-data-picker>
      </uni-forms-item>
      <uni-forms-item name="kecheng" label="学科">
        <uni-easyinput placeholder="如：数学" v-model="formData.kecheng" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="picurl" label="课程图">
        <uni-file-picker return-type="object" v-model="formData.picurl"></uni-file-picker>
      </uni-forms-item>
      <uni-forms-item name="orderid" label="排序">
        <uni-easyinput placeholder="请输入序号" type="number" v-model="formData.orderid"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="teacher" label="主讲教师">
        <uni-easyinput placeholder="如：张XX" v-model="formData.teacher" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="grade" label="面向学生">
        <uni-easyinput placeholder="如：高一，高二" v-model="formData.grade" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="introduce" label="联系方式">
        <uni-easyinput placeholder="" v-model="formData.introduce" trim="both"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="content" label="内容" required>
       <div id="div1"></div>
      </uni-forms-item>
      <uni-forms-item name="checked" label="状态">
        <uni-data-checkbox v-model="formData.checked" :localdata="formOptions.checked_localdata"></uni-data-checkbox>
      </uni-forms-item>
      <view class="uni-button-group">
        <button type="primary" class="uni-button" style="width: 100px;" @click="submit">提交</button>
        <navigator open-type="navigateBack" style="margin-left: 15px;">
          <button class="uni-button" style="width: 100px;">返回</button>
        </navigator>
      </view>
    </uni-forms>
  </view>
</template>

<script>
  import { validator } from '../../js_sdk/validator/zmjj_kecheng2.js';
 import E from 'wangeditor'
  const db = uniCloud.database();
  const dbCmd = db.command;
  const dbCollectionName = 'zmjj_kecheng2';
   let editor=null;

  function getValidator(fields) {
    let result = {}
    for (let key in validator) {
      if (fields.includes(key)) {
        result[key] = validator[key]
      }
    }
    return result
  }

  

  export default {
    data() {
      let formData = {
        "title": "",
        "navid": "",
        "kecheng": "",
        "picurl": null,
        "orderid": null,
        "teacher": "",
        "grade": "",
        "introduce": "",
        "content": "",
        "checked": true
      }
      return {
        formData,
        formOptions: {
          "checked_localdata": [
            {
              "value": true,
              "text": "显示"
            },
            {
              "value": false,
              "text": "隐藏"
            }
          ]
        },
        rules: {
          ...getValidator(Object.keys(formData))
        }
      }
    },
    onReady() {
      this.$refs.form.setRules(this.rules);
	   this.onWangEdit()
    },
    methods: {
      onWangEdit(){
      		  editor = new E('#div1');
      		  editor.config.zIndex = 0
      		  editor.config.onblur = (newHtml) => {		    
      			  this.formData.content = newHtml
      		  }
      		  
      		  editor.config.customUploadImg = function (resultFiles, insertImgFn) {		      
      			  resultFiles.forEach(item=>{				  
      				  let path = URL.createObjectURL(item);
      				  let name = item.name;
      				  uniCloud.uploadFile({
      				  	filePath:path,
      					cloudPath:name
      				  }).then(res=>{					  
      					  insertImgFn(res.fileID)
      				  })
      			  })
      		  }
      		  
      		  editor.create()
      },
      
      /**
       * 验证表单并提交
       */
      submit() {
        uni.showLoading({
          mask: true
        })
        this.$refs.form.validate().then((res) => {
          return this.submitForm(res)
        }).catch(() => {
        }).finally(() => {
          uni.hideLoading()
        })
      },

      /**
       * 提交表单
       */
      submitForm(value) {
        // 使用 clientDB 提交数据
        return db.collection(dbCollectionName).add(value).then((res) => {
          uni.showToast({
            title: '新增成功'
          })
          this.getOpenerEventChannel().emit('refreshData')
          setTimeout(() => uni.navigateBack(), 500)
        }).catch((err) => {
          uni.showModal({
            content: err.message || '请求服务失败',
            showCancel: false
          })
        })
      }
    }
  }
</script>
