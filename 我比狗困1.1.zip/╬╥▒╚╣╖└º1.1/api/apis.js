import {request} from "../utils/request"

//获取首页导航
export function listNav(){
  return request({
    url:"/nav2/get",
    method:"POST"
  })
}

//获取新闻列表
export function queryNews(data){
  return request({
    url:"/news/get",
    method:"POST",
    data
  })
}

//获取新闻详情
export function newsDetail(data){
  return request({
    url:"/news/detail",
    method:"POST",
    data
  })
}

//获取产品列表
export function queryProduct(data){
  return request({
    url:"/kecheng2/getlist",
    method:"POST",
    data
  })
}


//获取产品详情
export function queryProductDetail(data){
  return request({
    url:"/kecheng2/detail",
    method:"POST",
    data
  })
}
